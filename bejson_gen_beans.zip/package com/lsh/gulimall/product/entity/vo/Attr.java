/**
  * Copyright 2021 bejson.com 
  */
package package com.lsh.gulimall.product.entity.vo;

/**
 * Auto-generated: 2021-06-21 2:9:18
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Attr {

    private int attrId;
    private String attrName;
    private String attrValue;
    public void setAttrId(int attrId) {
         this.attrId = attrId;
     }
     public int getAttrId() {
         return attrId;
     }

    public void setAttrName(String attrName) {
         this.attrName = attrName;
     }
     public String getAttrName() {
         return attrName;
     }

    public void setAttrValue(String attrValue) {
         this.attrValue = attrValue;
     }
     public String getAttrValue() {
         return attrValue;
     }

}