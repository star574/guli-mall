/**
  * Copyright 2021 bejson.com 
  */
package package com.lsh.gulimall.product.entity.vo;

/**
 * Auto-generated: 2021-06-21 2:9:18
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class MemberPrice {

    private int id;
    private String name;
    private double price;
    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setPrice(double price) {
         this.price = price;
     }
     public double getPrice() {
         return price;
     }

}