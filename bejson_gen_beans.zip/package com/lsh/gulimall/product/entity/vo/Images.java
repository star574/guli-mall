/**
  * Copyright 2021 bejson.com 
  */
package package com.lsh.gulimall.product.entity.vo;

/**
 * Auto-generated: 2021-06-21 2:9:18
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Images {

    private String imgUrl;
    private int defaultImg;
    public void setImgUrl(String imgUrl) {
         this.imgUrl = imgUrl;
     }
     public String getImgUrl() {
         return imgUrl;
     }

    public void setDefaultImg(int defaultImg) {
         this.defaultImg = defaultImg;
     }
     public int getDefaultImg() {
         return defaultImg;
     }

}