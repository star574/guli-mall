/**
  * Copyright 2021 bejson.com 
  */
package package com.lsh.gulimall.product.entity.vo;

/**
 * Auto-generated: 2021-06-21 2:9:18
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Bounds {

    private int buyBounds;
    private int growBounds;
    public void setBuyBounds(int buyBounds) {
         this.buyBounds = buyBounds;
     }
     public int getBuyBounds() {
         return buyBounds;
     }

    public void setGrowBounds(int growBounds) {
         this.growBounds = growBounds;
     }
     public int getGrowBounds() {
         return growBounds;
     }

}